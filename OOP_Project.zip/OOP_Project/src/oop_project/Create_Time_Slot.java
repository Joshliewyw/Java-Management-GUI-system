/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package oop_project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Date;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Create_Time_Slot extends javax.swing.JFrame {
    private String [] columnName = {"Time From", "Time To", "Date"};
    private DefaultTableModel model = new DefaultTableModel();
    private int row = -1;

    public Create_Time_Slot() {
        model.setColumnIdentifiers(columnName);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Time_Slot_Table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Time_Slot_Date = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        Time_Slot_Hour = new javax.swing.JSpinner();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Time_Slot_Table.setModel(model);
        Time_Slot_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Time_Slot_TableMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(Time_Slot_Table);

        jLabel1.setText("Time Slot: ");

        jLabel3.setText("Date:");

        Time_Slot_Date.setMinSelectableDate(new Date(new Date().getTime() + (1000 * 60 * 60 * 24)));

        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Time_Slot_Hour.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(1735488000000L), null, null, java.util.Calendar.HOUR));
        Time_Slot_Hour.setEditor(new javax.swing.JSpinner.DateEditor(Time_Slot_Hour, "HH"));

        jButton2.setText("Remove");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Upload");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton5.setText("Home");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("View");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Shut Down");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton1)
                                .addComponent(jButton2)
                                .addComponent(jButton3)
                                .addComponent(Time_Slot_Date, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                                .addComponent(Time_Slot_Hour)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton5)
                            .addComponent(jButton6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(153, 153, 153))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton7)
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton5)
                        .addGap(10, 10, 10)
                        .addComponent(jButton6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Time_Slot_Hour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Time_Slot_Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(47, 47, 47)
                        .addComponent(jButton3)))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //add button, button used to add time slot to the Time_Slot_File.txt, auto sets it to 1 hour
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try {
    Date selectedHour = (Date) Time_Slot_Hour.getValue(); // Assuming Time_Slot_Hour is a JSpinner
    Date selectedDate = Time_Slot_Date.getDate(); // Assuming Time_Slot_Date is a JDateChooser

    if (selectedHour == null) {
        JOptionPane.showMessageDialog(this, "Please select a time for the first time slot.", "Missing Input", JOptionPane.WARNING_MESSAGE);
        return;
    }
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Please select a date.", "Missing Input", JOptionPane.WARNING_MESSAGE);
        return;
    }

    Calendar calendar = Calendar.getInstance();
    calendar.setTime(selectedHour);
    calendar.add(Calendar.HOUR_OF_DAY, 1);
    Date selectedHour2 = calendar.getTime();

    SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm"); // 24-hour format
    SimpleDateFormat displayFormatter = new SimpleDateFormat("hh:mm a"); // 12-hour format with AM/PM
    SimpleDateFormat dateFormatter = new SimpleDateFormat("dd MM yyyy"); // Date format: DD MM YYYY

    Date minTime = timeFormatter.parse("07:59"); 
    Date maxTime = timeFormatter.parse("18:00"); 

    String selectedTimeStr = timeFormatter.format(selectedHour);
    Date selectedTime = timeFormatter.parse(selectedTimeStr); 

    if (selectedTime.before(minTime) || selectedTime.after(maxTime)) {
        JOptionPane.showMessageDialog(this, "Please select a time between 8:00 AM and 6:00 PM.", "Invalid Time", JOptionPane.WARNING_MESSAGE);
        return;
    }

    String selectedTimeStr2 = timeFormatter.format(selectedHour2);
    Date selectedTime2 = timeFormatter.parse(selectedTimeStr2);

    if (selectedTime2.before(minTime) || selectedTime2.after(maxTime)) {
        JOptionPane.showMessageDialog(this, "The second time (hour+1) must also be between 8:00 AM and 6:00 PM.", "Invalid Time", JOptionPane.WARNING_MESSAGE);
        return;
    }

    String formattedTime = displayFormatter.format(selectedHour);
    String formattedTime2 = displayFormatter.format(selectedHour2);
    String formattedDate = dateFormatter.format(selectedDate);

    Object newData[] = {formattedTime, formattedTime2, formattedDate};
    model.addRow(newData); 

    Calendar resetCalendar = Calendar.getInstance();
    resetCalendar.set(Calendar.HOUR_OF_DAY, 0); // Set hour to 12:00 AM (00:00)
    resetCalendar.set(Calendar.MINUTE, 0);
    resetCalendar.set(Calendar.SECOND, 0);
    Time_Slot_Hour.setValue(resetCalendar.getTime()); // Reset spinner to 12:00 AM
    Time_Slot_Date.setDate(null);

} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(this, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void Time_Slot_TableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Time_Slot_TableMouseReleased
        row = Time_Slot_Table.getSelectedRow();

    if (row >= 0) {
        try {
            Date selectedHour = new SimpleDateFormat("hh:mm a").parse((String) model.getValueAt(row, 0)); // First column
            Date selectedDate = new SimpleDateFormat("dd MM yyyy").parse((String) model.getValueAt(row, 2)); // Third column

            Time_Slot_Hour.setValue(selectedHour); 
            Time_Slot_Date.setDate(selectedDate);  
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error while parsing data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a row from the table.", "No Selection", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_Time_Slot_TableMouseReleased

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        if (row == -1){
            JOptionPane.showMessageDialog(this,"You must select a row before you can delete it");
        }
        else{
        model.removeRow(row);
        
        Calendar resetCalendar = Calendar.getInstance();
        resetCalendar.set(Calendar.HOUR_OF_DAY, 0); // Set hour to 12:00 AM (00:00)
        resetCalendar.set(Calendar.MINUTE, 0);
        resetCalendar.set(Calendar.SECOND, 0);
        Time_Slot_Hour.setValue(resetCalendar.getTime()); // Reset spinner to 12:00 AM
        Time_Slot_Date.setDate(null);
        
        row= -1;
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
String teacherUsername = GlobalVariables.teacherUsernameGlobal;
    String teacherName = GlobalVariables.teacherNameGlobal;

    if (teacherUsername == null || teacherUsername.isEmpty() || teacherName == null || teacherName.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No teacher logged in. Please log in first.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String timeSlotFilePath = "Time_Slot_File.txt";
    String appointmentFilePath = "Appointment_File.txt";

    Set<String> existingTimeSlotEntries = new HashSet<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(timeSlotFilePath))) {
        String line;
        while ((line = reader.readLine()) != null) {
            existingTimeSlotEntries.add(line.trim());
        }
    } catch (FileNotFoundException e) {
        
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error reading time slot file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    Set<String> existingAppointments = new HashSet<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(appointmentFilePath))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length >= 7) {
                String key = parts[1].trim() + "," + parts[4].trim() + "," + parts[6].trim(); // Teacher_Username, Time_From, date
                existingAppointments.add(key);
            }
        }
    } catch (FileNotFoundException e) {
        
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error reading appointment file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(timeSlotFilePath, true))) {
        boolean addedAtLeastOne = false;

        for (int i = 0; i < model.getRowCount(); i++) {
            String timeFrom = model.getValueAt(i, 0).toString().trim();
            String timeTo = model.getValueAt(i, 1).toString().trim();
            String date = model.getValueAt(i, 2).toString().trim();

            String newTimeSlotEntry = teacherUsername + "," + teacherName + "," + timeFrom + "," + timeTo + "," + date;

            String appointmentKey = teacherUsername + "," + timeFrom + "," + date;

            if (!existingTimeSlotEntries.contains(newTimeSlotEntry) && !existingAppointments.contains(appointmentKey)) {
                writer.write(newTimeSlotEntry);
                writer.newLine();

                existingTimeSlotEntries.add(newTimeSlotEntry);
                addedAtLeastOne = true;
            }
        }

        if (addedAtLeastOne) {
            clearTable();
            JOptionPane.showMessageDialog(this, "Time slots have been successfully uploaded.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No new time slots were uploaded (all entries are duplicates).", "No Uploads", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "An error occurred while uploading the data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        View_Time_Slot sg = new View_Time_Slot();
        sg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to exit?", 
            "Exit Confirmation", 
            JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE);

    if (confirm == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        Teacher_Homepage sg = new Teacher_Homepage();
        sg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed
private void clearTable() {
    model.setRowCount(0);
}
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Create_Time_Slot().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser Time_Slot_Date;
    private javax.swing.JSpinner Time_Slot_Hour;
    private javax.swing.JTable Time_Slot_Table;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
